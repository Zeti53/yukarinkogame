// Dino-like runner: player moves right, obstacles are stationary on the ground
(function(){
    const canvas = document.getElementById('game');
    if(!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });

    function fitCanvas(){
        const rect = canvas.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        canvas.width = Math.floor(rect.width * dpr);
        canvas.height = Math.floor(rect.height * dpr);
        ctx.setTransform(dpr,0,0,dpr,0,0);
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
    }
    canvas.style.width = canvas.getAttribute('width') + 'px';
    canvas.style.height = canvas.getAttribute('height') + 'px';
    fitCanvas();
    window.addEventListener('resize', fitCanvas);

    const hudScore = document.getElementById('score');
    const overlay = document.getElementById('overlay');
    const finalScore = document.getElementById('final-score');
    const startBtn = document.getElementById('start-btn');
    const restartBtn = document.getElementById('restart-btn');
    const upBtn = document.getElementById('up-btn');
    const downBtn = document.getElementById('down-btn');

    let groundGap = 48;
    let lastTime = 0;
    let gameOver = false;
    let isPlaying = false;
    let flashAlpha = 0;
    let shakeTimer = 0;
    let shakeMag = 0;

    const player = {
        x: 0, y: 0, width: 44, normalHeight: 50, crouchHeight: 30, height: 50,
        vy: 0, gravity: 1.1, speed: 3.6, jumpVel: 22,
        isOnGround: true, isCrouched: false, crouchTimeout: null
    };

    let cameraX = 0;
    let obstacles = [];
    let platforms = [];
    let lastObstacleX = 0;
    let lastPlatformX = 0;
    let dust = [];
    let flames = [];
    let explosions = [];
    let portals = [];
    let gyozas = [];
    let score = 0;
    let nextGyozaX = 300 + Math.random() * 400;

    function groundY(){ return canvas.getBoundingClientRect().height - groundGap; }

    function drawBackground(ctx, w, h, cameraX){
        const skyShift = cameraX * 0.08;
        const skyGrad = ctx.createLinearGradient(0,0,0,h);
        skyGrad.addColorStop(0, '#ffd1e8');
        skyGrad.addColorStop(0.5, '#ffe4f1');
        skyGrad.addColorStop(1, '#fff0f8');
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0,0,w,h);

        ctx.save();
        ctx.translate(-skyShift, 0);
        const fujiX = w * 0.65, fujiY = h * 0.55, fujiW = 200, fujiH = 100;
        const mountainGrad = ctx.createLinearGradient(fujiX, fujiY - fujiH, fujiX, fujiY);
        mountainGrad.addColorStop(0, '#e8d4f0');
        mountainGrad.addColorStop(0.6, '#c8b3e0');
        mountainGrad.addColorStop(1, '#d4c5e8');
        ctx.fillStyle = mountainGrad;
        ctx.beginPath();
        ctx.moveTo(fujiX - fujiW/2, fujiY);
        ctx.lineTo(fujiX, fujiY - fujiH);
        ctx.lineTo(fujiX + fujiW/2, fujiY);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.moveTo(fujiX - 20, fujiY - fujiH * 0.6);
        ctx.lineTo(fujiX, fujiY - fujiH);
        ctx.lineTo(fujiX + 20, fujiY - fujiH * 0.6);
        ctx.closePath();
        ctx.fill();
        ctx.restore();

        ctx.save();
        ctx.translate(-skyShift * 1.5, 0);
        const towerX = w * 0.2, towerY = h * 0.65, towerW = 40, towerH = 120;
        ctx.fillStyle = '#ffb3d9';
        ctx.fillRect(towerX - towerW*0.5, towerY, towerW, towerH*0.4);
        ctx.fillStyle = '#ffe0f0';
        ctx.fillRect(towerX - towerW*0.35, towerY - towerH*0.4, towerW*0.7, towerH*0.4);
        ctx.fillStyle = '#ff9ec8';
        ctx.fillRect(towerX - towerW*0.2, towerY - towerH*0.8, towerW*0.4, towerH*0.4);
        ctx.strokeStyle = '#ff9ec8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(towerX, towerY - towerH*0.8);
        ctx.lineTo(towerX, towerY - towerH*1.1);
        ctx.stroke();
        ctx.restore();

        ctx.save();
        ctx.translate(-skyShift * 2.0, 0);
        const pagX = w * 0.85, pagY = h * 0.7, pagW = 30;
        for(let i=0; i<3; i++){
            ctx.fillStyle = '#ffd4e8';
            ctx.fillRect(pagX - pagW*0.5, pagY - i*15, pagW, 12);
            ctx.fillStyle = '#c8b3e0';
            ctx.fillRect(pagX - pagW*0.6, pagY - i*15 - 1, pagW*1.2, 2);
        }
        ctx.restore();

        ctx.save();
        ctx.translate(-skyShift * 1.2, 0);
        const toriiX = w * 0.4, toriiY = h * 0.75;
        ctx.fillStyle = '#ffb8d4';
        ctx.fillRect(toriiX - 25, toriiY, 8, 60);
        ctx.fillRect(toriiX + 17, toriiY, 8, 60);
        ctx.fillRect(toriiX - 30, toriiY, 60, 6);
        ctx.fillRect(toriiX - 25, toriiY + 20, 50, 5);
        ctx.restore();
    }

    function rectsIntersect(r1, r2){ return r1.x < r2.x + r2.width && r1.x + r1.width > r2.x && r1.y < r2.y + r2.height && r1.y + r1.height > r2.y; }

    function createObstacles(){
        obstacles = [];
        lastObstacleX = 300;
    }

    function addNewObstacles(){
        const w = 12 + Math.round(Math.random()*20);
        const h = 20 + Math.round(Math.random()*28);
        obstacles.push({ x: lastObstacleX, width: w, height: h });
        lastObstacleX += (w + 80 + Math.round(Math.random()*40)) * 5;
    }

    function createPlatforms(){
        platforms = [];
        lastPlatformX = 400;
    }

    function addNewPlatform(){
        const w = 80 + Math.round(Math.random()*60);
        const y = groundY() - 90 - Math.round(Math.random()*60);
        platforms.push({ x: lastPlatformX, y: y, width: w, height: 12 });
        lastPlatformX += 360 + Math.round(Math.random()*140);
    }

    function spawnPortalAt(worldX, worldY){
        portals.push({ x: worldX, y: worldY, t:0, life:60, radius:4 });
        for(let i=0; i<22; i++){
            const ang = Math.random()*Math.PI*2, sp = 1 + Math.random()*4;
            explosions.push({ x: worldX, y: worldY, vx: Math.cos(ang)*sp, vy: Math.sin(ang)*sp, age:0, life:50 + Math.random()*40, size:2 + Math.random()*3, color: `rgba(255,${80+Math.round(Math.random()*120)},0,1)` });
        }
        flashAlpha = 0.95; shakeTimer = 22; shakeMag = 8;
    }

    function spawnGyozaAt(worldX, worldY){
        gyozas.push({ x: worldX, y: worldY, vx: 0, phase: Math.random()*6, size: 24 });
        if(gyozas.length > 48) gyozas.shift();
    }

    function startRun(){
        player.height = player.normalHeight;
        player.y = groundY() - player.height;
        player.vy = 0;
        player.isOnGround = true;
        player.isCrouched = false;
        player.x = 0;
        cameraX = 0;
        gameOver = false;
        isPlaying = true;
        dust.length = flames.length = explosions.length = portals.length = 0;
        gyozas.length = 0;
        score = 0;
        nextGyozaX = player.x + 300 + Math.random() * 400;
        createObstacles();
        createPlatforms();
        for(let i=0; i<3; i++){
            spawnGyozaAt(player.x + 140 + i*60, groundY() - 60 - Math.random()*40);
        }
        if(hudScore) hudScore.textContent = 'Punkty: 0';
        lastTime = performance.now();
    }

    function jump(){
        if(gameOver) return;
        if(!isPlaying) startRun();
        if(player.isOnGround && !player.isCrouched){
            player.vy = -player.jumpVel;
            player.isOnGround = false;
        }
    }

    function crouch(){
        if(gameOver || !isPlaying || player.isCrouched) return;
        if(player.isOnGround){
            player.isCrouched = true;
            player.height = player.crouchHeight;
            player.y = groundY() - player.height;
            clearTimeout(player.crouchTimeout);
            player.crouchTimeout = setTimeout(()=>{
                player.isCrouched = false;
                player.height = player.normalHeight;
                player.y = groundY() - player.height;
            }, 700);
        }
    }

    window.addEventListener('keydown', (e)=>{
        if(e.code === 'Space' || e.key === 'ArrowUp') { e.preventDefault(); jump(); }
        if(e.key === 'ArrowDown') { e.preventDefault(); crouch(); }
    });

    if(upBtn){
        upBtn.addEventListener('mousedown', jump);
        upBtn.addEventListener('touchstart', (e)=>{ e.preventDefault(); jump(); });
    }
    if(downBtn){
        downBtn.addEventListener('mousedown', crouch);
        downBtn.addEventListener('touchstart', (e)=>{ e.preventDefault(); crouch(); });
    }
    canvas.addEventListener('touchstart', (e)=>{ e.preventDefault(); jump(); });
    canvas.addEventListener('mousedown', (e)=>{ e.preventDefault(); jump(); });

    if(startBtn){ startBtn.addEventListener('click', ()=>{ if(overlay) overlay.classList.add('hidden'); startRun(); }); }
    if(restartBtn){ restartBtn.addEventListener('click', ()=>{ if(overlay) overlay.classList.add('hidden'); startRun(); }); }

    function gameEnd(){
        gameOver = true;
        isPlaying = false;
        const worldX = player.x;
        const worldY = player.y + player.height * 0.6;
        spawnPortalAt(worldX, worldY);
        if(finalScore) finalScore.textContent = 'Punkty: ' + score;
        const title = document.getElementById('game-over-title');
        if(title) title.textContent = 'GAME OVER';
        
        // Save score to server
        if(typeof saveScore === 'function') {
            saveScore(score);
        }
        
        setTimeout(()=>{ 
            if(overlay) overlay.classList.remove('hidden'); 
            setTimeout(()=>{ 
                if(overlay) overlay.classList.add('hidden'); 
            }, 2000);
        }, 2000);
    }

    function spawnDust(worldX, worldY){
        dust.push({ x: worldX + (Math.random()-0.5)*8, y: worldY, vx: -0.4 - Math.random()*0.6, vy: -0.2 - Math.random()*0.6, life: 30 + Math.random()*20, age:0, size:4+Math.random()*6 });
        if(dust.length > 120) dust.shift();
    }

    function updateParticles(){
        for(let i=dust.length-1; i>=0; i--){
            const p = dust[i];
            p.x += p.vx; p.y += p.vy; p.age++; p.vy += 0.05;
            if(p.age > p.life) dust.splice(i,1);
        }
        for(let i=explosions.length-1; i>=0; i--){
            const e = explosions[i];
            e.x += e.vx; e.y += e.vy; e.vy += 0.08; e.age++;
            if(e.age > e.life) explosions.splice(i,1);
        }
        for(let i=portals.length-1; i>=0; i--){
            const q = portals[i];
            q.t++; q.radius += 0.8;
            if(q.t > q.life) portals.splice(i,1);
        }
    }

    function update(delta){
        const dt = delta/16;
        const prevY = player.y;
        if(isPlaying){ player.x += player.speed * dt; }
        const screenPlayerX = 120;
        cameraX = player.x - screenPlayerX;
        player.vy += player.gravity * dt;
        player.y += player.vy * dt;
        const gY = groundY() - player.height;
        if(player.y > gY){
            player.y = gY;
            player.vy = 0;
            player.isOnGround = true;
        }

        const hitX = screenPlayerX - 8;
        const hitW = 20;

        for(const ob of obstacles){
            const obScreenX = ob.x - cameraX;
            if(obScreenX > canvas.getBoundingClientRect().width + 50) continue;
            const playerRect = { x: hitX, y: player.y, width: hitW, height: player.height };
            const obRect = { x: obScreenX, y: groundY() - ob.height, width: ob.width, height: ob.height };
            if(rectsIntersect(playerRect, obRect) && !gameOver){
                gameEnd();
                break;
            }
        }

        const playerBottomPrev = prevY + player.height;
        const playerBottomNow = player.y + player.height;
        for(const p of platforms){
            const pScreenX = p.x - cameraX;
            const pTop = p.y;
            if(pScreenX + p.width < -50 || pScreenX > canvas.getBoundingClientRect().width + 50) continue;
            const playerLeft = hitX;
            const playerRight = hitX + hitW;
            const platLeft = pScreenX;
            const platRight = pScreenX + p.width;
            if(playerBottomPrev <= pTop && playerBottomNow >= pTop && playerRight > platLeft + 4 && playerLeft < platRight - 4 && player.vy >= 0){
                player.y = pTop - player.height;
                player.vy = 0;
                player.isOnGround = true;
                break;
            }
        }

        if(player.isOnGround){
            if(player.y >= groundY() - player.height - 0.5){
                player.isOnGround = true;
            } else {
                let stillOn = false;
                for(const p of platforms){
                    const pScreenX = p.x - cameraX;
                    const pTop = p.y;
                    const playerLeft = hitX;
                    const playerRight = hitX + hitW;
                    if(Math.abs((player.y + player.height) - pTop) < 1 && playerRight > pScreenX + 2 && playerLeft < pScreenX + p.width - 2){
                        stillOn = true;
                        break;
                    }
                }
                if(!stillOn && player.y + player.height < groundY()){
                    player.isOnGround = false;
                }
            }
        }

        if(isPlaying && player.isOnGround){
            if(Math.random() < 0.35) spawnDust(player.x - 6, groundY());
        }

        while(lastObstacleX < player.x + 1500){
            addNewObstacles();
        }

        while(lastPlatformX < player.x + 1500){
            addNewPlatform();
        }

        obstacles = obstacles.filter(ob => ob.x > player.x - 500);
        platforms = platforms.filter(p => p.x > player.x - 500);

        if(isPlaying && player.x >= nextGyozaX){
            const count = 1 + (Math.random() < 0.5 ? 1 : 0);
            for(let i=0; i<count; i++){
                const wx = player.x + 220 + Math.random()*320 + i*50;
                const wy = groundY() - 50 - Math.random()*100;
                gyozas.push({ x: wx, y: wy, vx: 0, phase: Math.random()*6, size: 24 });
            }
            nextGyozaX = player.x + 150 + Math.random()*250;
        }

        for(let i=gyozas.length-1; i>=0; i--){
            const g = gyozas[i];
            g.phase += dt * 0.08;
            g.y += Math.sin(g.phase) * 0.5 * dt;
            const playerRect = { x: hitX, y: player.y, width: hitW, height: player.height };
            const gScreenX = g.x - cameraX;
            const gRect = { x: gScreenX - g.size*0.5, y: g.y - g.size*0.5, width: g.size, height: g.size };
            if(rectsIntersect(playerRect, gRect) && !gameOver){
                score += 1;
                gyozas.splice(i,1);
            }
        }

        if(hudScore) hudScore.textContent = 'Punkty: ' + score;
        updateParticles();
        if(flashAlpha > 0){ flashAlpha -= 0.03; if(flashAlpha < 0) flashAlpha = 0; }
        if(shakeTimer > 0){ shakeTimer--; if(shakeTimer <= 0) shakeMag = 0; }
    }

    function draw(){
        const w = canvas.getBoundingClientRect().width;
        const h = canvas.getBoundingClientRect().height;
        ctx.clearRect(0,0,w,h);

        drawBackground(ctx, w, h, cameraX);

        const groundGrad = ctx.createLinearGradient(0, groundY(), 0, h);
        groundGrad.addColorStop(0, '#ffe8f5');
        groundGrad.addColorStop(1, '#ffd4eb');
        ctx.fillStyle = groundGrad;
        ctx.fillRect(0, groundY(), w, h - groundY());
        ctx.fillStyle = '#d4f0d4';
        for(let i = 0; i < w; i += 8){
            ctx.fillRect(i, groundY(), 4, 2);
        }

        for(const p of platforms){
            const sx = p.x - cameraX;
            if(sx + p.width < -50 || sx > w + 50) continue;
            const platGrad = ctx.createLinearGradient(sx, p.y, sx, p.y + p.height);
            platGrad.addColorStop(0, '#ffc4e8');
            platGrad.addColorStop(1, '#ffb0dc');
            ctx.fillStyle = platGrad;
            ctx.fillRect(sx, p.y, p.width, p.height);
            ctx.fillStyle = '#ffe0f0';
            ctx.fillRect(sx, p.y, p.width, 3);
            ctx.strokeStyle = '#ff9ed4';
            ctx.lineWidth = 2;
            ctx.strokeRect(sx, p.y, p.width, p.height);
        }

        for(const ob of obstacles){
            const sx = ob.x - cameraX;
            if(sx + ob.width < -50 || sx > w + 50) continue;
            const oy = groundY() - ob.height;
            const flowerGrad = ctx.createLinearGradient(sx, oy, sx, oy + ob.height);
            flowerGrad.addColorStop(0, '#b8e6b8');
            flowerGrad.addColorStop(1, '#90d890');
            ctx.fillStyle = flowerGrad;
            ctx.fillRect(sx, oy, ob.width, ob.height);
            ctx.strokeStyle = '#8dc88d';
            ctx.lineWidth = 3;
            ctx.strokeRect(sx + 1, oy + 1, ob.width - 2, ob.height - 2);
            const cx = sx + ob.width * 0.5;
            const cy = oy - 6;
            ctx.fillStyle = '#ffc0d8';
            ctx.beginPath();
            ctx.arc(cx, cy, ob.width * 0.4, 0, Math.PI*2);
            ctx.fill();
            ctx.fillStyle = '#ffe0a0';
            ctx.beginPath();
            ctx.arc(cx, cy, ob.width * 0.15, 0, Math.PI*2);
            ctx.fill();
        }

        for(let i = 0; i < dust.length; i += 2){
            const d = dust[i];
            const sx = d.x - cameraX;
            const alpha = 0.6 * (1 - d.age/d.life);
            ctx.fillStyle = `rgba(255,192,220,${alpha})`;
            ctx.beginPath();
            ctx.arc(sx, d.y, d.size*(1 - d.age/d.life), 0, Math.PI*2);
            ctx.fill();
        }

        // draw gyozas (kawaii style)
        for(const g of gyozas){
            const sx = g.x - cameraX;
            if(sx < -50 || sx > w + 50) continue;
            ctx.save();
            ctx.translate(sx, g.y);
            ctx.rotate(Math.sin(g.phase)*0.1);

            ctx.fillStyle = 'rgba(0,0,0,0.12)';
            ctx.beginPath();
            if(ctx.ellipse) ctx.ellipse(0, g.size*0.55, g.size*0.9, g.size*0.3, 0, 0, Math.PI*2);
            ctx.fill();

            const gyozaGrad = ctx.createRadialGradient(-g.size*0.2, -g.size*0.3, 0, 0, 0, g.size*1.2);
            gyozaGrad.addColorStop(0, '#fff4d6');
            gyozaGrad.addColorStop(0.6, '#f5e6c8');
            gyozaGrad.addColorStop(1, '#e8d4b0');
            ctx.fillStyle = gyozaGrad;
            ctx.beginPath();
            ctx.arc(0, 0, g.size*0.95, Math.PI, Math.PI*2);
            ctx.lineTo(g.size*0.95, 0);
            ctx.bezierCurveTo(g.size*0.95, -g.size*0.4, -g.size*0.95, -g.size*0.4, -g.size*0.95, 0);
            ctx.closePath();
            ctx.fill();

            ctx.strokeStyle = '#d4c0a0';
            ctx.lineWidth = 1.5;
            ctx.lineCap = 'round';
            ctx.beginPath();
            const crimps = 5;
            for(let i = 0; i < crimps; i++){
                const angle = Math.PI + (Math.PI / (crimps+1)) * (i+1);
                const x1 = Math.cos(angle) * g.size * 0.85;
                const y1 = Math.sin(angle) * g.size * 0.45;
                const x2 = Math.cos(angle) * g.size * 0.7;
                const y2 = Math.sin(angle) * g.size * 0.3;
                ctx.moveTo(x1, y1);
                ctx.lineTo(x2, y2);
            }
            ctx.stroke();

            ctx.fillStyle = '#333';
            ctx.beginPath();
            ctx.arc(-g.size*0.25, -g.size*0.1, g.size*0.08, 0, Math.PI*2);
            ctx.arc(g.size*0.25, -g.size*0.1, g.size*0.08, 0, Math.PI*2);
            ctx.fill();

            ctx.fillStyle = '#fff';
            ctx.beginPath();
            ctx.arc(-g.size*0.23, -g.size*0.13, g.size*0.03, 0, Math.PI*2);
            ctx.arc(g.size*0.27, -g.size*0.13, g.size*0.03, 0, Math.PI*2);
            ctx.fill();

            ctx.fillStyle = 'rgba(255, 180, 180, 0.5)';
            ctx.beginPath();
            ctx.ellipse(-g.size*0.5, 0.05, g.size*0.15, g.size*0.1, 0, 0, Math.PI*2);
            ctx.ellipse(g.size*0.5, 0.05, g.size*0.15, g.size*0.1, 0, 0, Math.PI*2);
            ctx.fill();

            ctx.strokeStyle = '#ff8844';
            ctx.lineWidth = 1.8;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.arc(0, 0, g.size*0.2, 0.2, Math.PI-0.2);
            ctx.stroke();

            ctx.fillStyle = 'rgba(255,255,255,0.4)';
            ctx.beginPath();
            if(ctx.ellipse) ctx.ellipse(-g.size*0.15, -g.size*0.3, g.size*0.35, g.size*0.2, -0.3, 0, Math.PI*2);
            ctx.fill();

            ctx.restore();
        }

        // draw player (anime girl style)
        const screenPlayerX = 120;
        const px = screenPlayerX;
        const py = player.y;
        const phase = Math.floor(player.x / 8) % 2;

        // shadow
        ctx.fillStyle = 'rgba(0,0,0,0.25)';
        ctx.beginPath();
        ctx.ellipse(px, groundY()+3, 16, 5, 0, 0, Math.PI*2);
        ctx.fill();

        // legs
        ctx.fillStyle = '#2a2a2a';
        const legH = 12;
        const legY = py + player.height - legH;
        ctx.fillRect(px - 8, legY, 5, legH);
        ctx.fillRect(px + 3, legY, 5, legH);
        
        // shoes
        ctx.fillStyle = '#444';
        ctx.fillRect(px - 9, legY + legH - 3, 7, 3);
        ctx.fillRect(px + 2, legY + legH - 3, 7, 3);

        // skirt
        ctx.fillStyle = '#2a2a2a';
        ctx.beginPath();
        ctx.moveTo(px - 10, py + 18);
        ctx.lineTo(px - 14, py + 30);
        ctx.lineTo(px + 14, py + 30);
        ctx.lineTo(px + 10, py + 18);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#1a1a1a';
        ctx.lineWidth = 1;
        ctx.stroke();

        // shirt/body
        ctx.fillStyle = '#f5f5f5';
        ctx.fillRect(px - 9, py + 12, 18, 12);
        ctx.strokeStyle = '#e0e0e0';
        ctx.strokeRect(px - 9, py + 12, 18, 12);
        
        // collar
        ctx.fillStyle = '#e8e8e8';
        ctx.beginPath();
        ctx.moveTo(px - 8, py + 12);
        ctx.lineTo(px - 10, py + 16);
        ctx.lineTo(px, py + 15);
        ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(px + 8, py + 12);
        ctx.lineTo(px + 10, py + 16);
        ctx.lineTo(px, py + 15);
        ctx.closePath();
        ctx.fill();

        // head
        ctx.fillStyle = '#ffd8b5';
        ctx.beginPath();
        ctx.arc(px, py + 6, 10, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#f0c8a0';
        ctx.lineWidth = 0.5;
        ctx.stroke();

        // hair (black)
        ctx.fillStyle = '#1a1a1a';
        // top of head
        ctx.beginPath();
        ctx.arc(px, py + 4, 11, Math.PI, Math.PI * 2);
        ctx.fill();
        // side hair
        ctx.fillRect(px - 11, py + 2, 4, 8);
        ctx.fillRect(px + 7, py + 2, 4, 8);
        // hair strands
        ctx.beginPath();
        ctx.moveTo(px - 3, py - 2);
        ctx.lineTo(px - 5, py - 5);
        ctx.lineTo(px - 2, py - 4);
        ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(px + 3, py - 2);
        ctx.lineTo(px + 5, py - 5);
        ctx.lineTo(px + 2, py - 4);
        ctx.closePath();
        ctx.fill();

        // eyes (kawaii)
        ctx.fillStyle = '#1a1a1a';
        ctx.beginPath();
        ctx.arc(px - 3, py + 5, 1.8, 0, Math.PI * 2);
        ctx.arc(px + 3, py + 5, 1.8, 0, Math.PI * 2);
        ctx.fill();
        
        // eye highlights
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(px - 2.5, py + 4.5, 0.8, 0, Math.PI * 2);
        ctx.arc(px + 3.5, py + 4.5, 0.8, 0, Math.PI * 2);
        ctx.fill();

        // blush
        ctx.fillStyle = 'rgba(255, 180, 180, 0.4)';
        ctx.beginPath();
        ctx.ellipse(px - 6, py + 7, 2, 1.5, 0, 0, Math.PI * 2);
        ctx.ellipse(px + 6, py + 7, 2, 1.5, 0, 0, Math.PI * 2);
        ctx.fill();

        // smile
        ctx.strokeStyle = '#d08080';
        ctx.lineWidth = 1;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(px, py + 7, 3, 0.2, Math.PI - 0.2);
        ctx.stroke();

        // arms
        const armW = 3, armH = 11;
        ctx.fillStyle = '#ffd8b5';
        if(phase === 0){
            // left arm forward
            ctx.save();
            ctx.translate(px - 11, py + 15);
            ctx.rotate(-0.3);
            ctx.fillRect(0, 0, armW, armH);
            ctx.restore();
            // right arm back
            ctx.save();
            ctx.translate(px + 8, py + 17);
            ctx.rotate(0.2);
            ctx.fillRect(0, 0, armW, armH);
            ctx.restore();
        } else {
            // left arm back
            ctx.save();
            ctx.translate(px - 11, py + 17);
            ctx.rotate(-0.2);
            ctx.fillRect(0, 0, armW, armH);
            ctx.restore();
            // right arm forward
            ctx.save();
            ctx.translate(px + 8, py + 15);
            ctx.rotate(0.3);
            ctx.fillRect(0, 0, armW, armH);
            ctx.restore();
        }

        for(const q of portals){
            const sx = q.x - cameraX;
            ctx.save();
            ctx.strokeStyle = 'rgba(255,100,220,'+(1 - q.t/q.life)+')';
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(sx, q.y, q.radius, 0, Math.PI*2);
            ctx.stroke();
            ctx.restore();
        }

        for(const e of explosions){
            const sx = e.x - cameraX;
            const alpha = 1 - e.age/e.life;
            const newColor = e.color.replace(/rgba\(\d+,\d+,\d+,1\)/, 'rgba(255,180,220,1)');
            ctx.fillStyle = newColor.replace(/,1\)$/, ','+alpha+')');
            ctx.beginPath();
            ctx.arc(sx, e.y, e.size*(1 + e.age/10), 0, Math.PI*2);
            ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,'+alpha*0.6+')';
            ctx.beginPath();
            ctx.arc(sx, e.y, e.size*(1 + e.age/10)*0.4, 0, Math.PI*2);
            ctx.fill();
        }

        if(flashAlpha > 0){
            ctx.save();
            ctx.fillStyle = 'rgba(255,200,255,'+flashAlpha+')';
            ctx.fillRect(0,0,w,h);
            ctx.restore();
        }
    }

    function loop(ts){
        const delta = Math.min(40, ts - lastTime || 16);
        lastTime = ts;
        update(delta);
        draw();
        requestAnimationFrame(loop);
    }

    player.y = groundY() - player.height;
    createObstacles();
    createPlatforms();
    if(overlay){
        overlay.classList.add('hidden');
        const titleEl = document.getElementById('game-over-title');
        if(titleEl) titleEl.textContent = '';
        if(finalScore) finalScore.textContent = '';
    }
    lastTime = performance.now();
    requestAnimationFrame(loop);

})();
