# Serve this folder on http://localhost:8000 and open the page in the default browser (Windows PowerShell)
$port = 8000
Write-Host "Starting local HTTP server on port $port..."
# Try Python3 first
if (Get-Command python -ErrorAction SilentlyContinue) {
    Start-Process -NoNewWindow python -ArgumentList "-m","http.server","$port"
} elseif (Get-Command python3 -ErrorAction SilentlyContinue) {
    Start-Process -NoNewWindow python3 -ArgumentList "-m","http.server","$port"
} else {
    Write-Host "Python not found. Install Python or run an alternative static server (e.g., `npx http-server`)."
    exit 1
}
Start-Sleep -Milliseconds 600
Start-Process "http://localhost:$port/index.html"
Write-Host "Server started. Press Ctrl+C in the server terminal to stop it."
