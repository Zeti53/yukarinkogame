const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Simple in-memory database (users stored in JSON file)
const DB_FILE = path.join(__dirname, 'users.json');

function loadUsers() {
    try {
        if (fs.existsSync(DB_FILE)) {
            const data = fs.readFileSync(DB_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (err) {
        console.error('Error loading users:', err);
    }
    return [];
}

function saveUsers(users) {
    try {
        fs.writeFileSync(DB_FILE, JSON.stringify(users, null, 2));
    } catch (err) {
        console.error('Error saving users:', err);
    }
}

function hashPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex');
}

function generateToken() {
    return crypto.randomBytes(32).toString('hex');
}

const server = http.createServer((req, res) => {
    // API endpoints
    if (req.url.startsWith('/api/')) {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', () => {
            const users = loadUsers();
            
            // Register endpoint
            if (req.url === '/api/register' && req.method === 'POST') {
                try {
                    const { username, email, password } = JSON.parse(body);
                    
                    // Validate input
                    if (!username || !email || !password) {
                        res.writeHead(400, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'Wszystkie pola są wymagane' }));
                        return;
                    }
                    
                    if (password.length < 6) {
                        res.writeHead(400, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'Hasło musi mieć co najmniej 6 znaków' }));
                        return;
                    }
                    
                    // Check if user exists
                    if (users.find(u => u.email === email)) {
                        res.writeHead(400, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'Użytkownik z tym emailem już istnieje' }));
                        return;
                    }
                    
                    if (users.find(u => u.username === username)) {
                        res.writeHead(400, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'Ta nazwa użytkownika jest już zajęta' }));
                        return;
                    }
                    
                    // Create new user
                    const newUser = {
                        id: Date.now().toString(),
                        username,
                        email,
                        password: hashPassword(password),
                        highScore: 0,
                        totalScore: 0,
                        gamesPlayed: 0,
                        gamesHistory: [],
                        createdAt: new Date().toISOString()
                    };
                    
                    users.push(newUser);
                    saveUsers(users);
                    
                    res.writeHead(201, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ message: 'Rejestracja pomyślna' }));
                } catch (err) {
                    res.writeHead(500, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ message: 'Błąd serwera' }));
                }
                return;
            }
            
            // Login endpoint
            if (req.url === '/api/login' && req.method === 'POST') {
                try {
                    const { email, password } = JSON.parse(body);
                    
                    if (!email || !password) {
                        res.writeHead(400, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'Email i hasło są wymagane' }));
                        return;
                    }
                    
                    const user = users.find(u => u.email === email);
                    
                    if (!user || user.password !== hashPassword(password)) {
                        res.writeHead(401, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'Nieprawidłowy email lub hasło' }));
                        return;
                    }
                    
                    const token = generateToken();
                    
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ 
                        message: 'Logowanie pomyślne',
                        token,
                        username: user.username,
                        userId: user.id,
                        highScore: user.highScore || 0,
                        totalScore: user.totalScore || 0,
                        gamesPlayed: user.gamesPlayed || 0
                    }));
                } catch (err) {
                    res.writeHead(500, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ message: 'Błąd serwera' }));
                }
                return;
            }
            
            // Save score endpoint
            if (req.url === '/api/save-score' && req.method === 'POST') {
                try {
                    const { userId, score } = JSON.parse(body);
                    
                    if (!userId || score === undefined) {
                        res.writeHead(400, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'userId i score są wymagane' }));
                        return;
                    }
                    
                    const userIndex = users.findIndex(u => u.id === userId);
                    
                    if (userIndex === -1) {
                        res.writeHead(404, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'Użytkownik nie znaleziony' }));
                        return;
                    }
                    
                    // Initialize fields if they don't exist
                    if (!users[userIndex].totalScore) users[userIndex].totalScore = 0;
                    if (!users[userIndex].gamesPlayed) users[userIndex].gamesPlayed = 0;
                    if (!users[userIndex].gamesHistory) users[userIndex].gamesHistory = [];
                    
                    // Update high score if new score is higher
                    if (!users[userIndex].highScore || score > users[userIndex].highScore) {
                        users[userIndex].highScore = score;
                    }
                    
                    // Add to total score and games played
                    users[userIndex].totalScore += score;
                    users[userIndex].gamesPlayed += 1;
                    
                    // Add to games history (keep last 10 games)
                    users[userIndex].gamesHistory.unshift({
                        score: score,
                        date: new Date().toISOString()
                    });
                    if (users[userIndex].gamesHistory.length > 10) {
                        users[userIndex].gamesHistory = users[userIndex].gamesHistory.slice(0, 10);
                    }
                    
                    saveUsers(users);
                    
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ 
                        message: 'Wynik zapisany',
                        highScore: users[userIndex].highScore,
                        totalScore: users[userIndex].totalScore,
                        gamesPlayed: users[userIndex].gamesPlayed
                    }));
                } catch (err) {
                    res.writeHead(500, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ message: 'Błąd serwera' }));
                }
                return;
            }
            
            // Get user stats endpoint
            if (req.url.startsWith('/api/user-stats/') && req.method === 'GET') {
                try {
                    const userId = req.url.split('/').pop();
                    const user = users.find(u => u.id === userId);
                    
                    if (!user) {
                        res.writeHead(404, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ message: 'Użytkownik nie znaleziony' }));
                        return;
                    }
                    
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ 
                        username: user.username,
                        highScore: user.highScore || 0,
                        totalScore: user.totalScore || 0,
                        gamesPlayed: user.gamesPlayed || 0,
                        gamesHistory: user.gamesHistory || []
                    }));
                } catch (err) {
                    res.writeHead(500, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ message: 'Błąd serwera' }));
                }
                return;
            }
            
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Endpoint not found' }));
        });
        return;
    }
    
    // Serve static files
    let filePath = req.url === '/' ? '/register.html' : req.url;
    filePath = path.join(__dirname, filePath);
    
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('Not Found');
            return;
        }
        
        const ext = path.extname(filePath).slice(1);
        const contentTypes = {
            'html': 'text/html',
            'js': 'text/javascript',
            'css': 'text/css',
            'png': 'image/png',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg'
        };
        
        const contentType = contentTypes[ext] || 'text/plain';
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(data);
    });
});

const PORT = 8080;

// Get all network interfaces
const os = require('os');
const networkInterfaces = os.networkInterfaces();
const networkAddresses = [];

Object.keys(networkInterfaces).forEach((ifaceName) => {
    networkInterfaces[ifaceName].forEach((iface) => {
        if (iface.family === 'IPv4' && !iface.internal) {
            networkAddresses.push(iface.address);
        }
    });
});

server.listen(PORT, '0.0.0.0', () => {
    console.log('=================================');
    console.log('✨ Server is running! ✨');
    console.log('=================================');
    console.log(`📱 Local: http://localhost:${PORT}`);
    
    if (networkAddresses.length > 0) {
        console.log('\n🌐 Network Access (use on phone/tablet):');
        networkAddresses.forEach((addr) => {
            console.log(`   http://${addr}:${PORT}`);
        });
    }
    
    console.log('\n=================================');
    console.log('💡 To play on your phone:');
    console.log('   1. Make sure phone is on same WiFi');
    console.log('   2. Open browser on phone');
    console.log('   3. Enter one of the network URLs above');
    console.log('=================================');
    console.log('\n⏹️  Press Ctrl+C to stop the server\n');
});
