# Remove the Startup shortcut for Yukarinko server
$ErrorActionPreference = 'SilentlyContinue'
$startup = [Environment]::GetFolderPath('Startup')
$shortcutPath = Join-Path $startup 'YukarinkoServer.lnk'
if (Test-Path $shortcutPath) {
    Remove-Item $shortcutPath -Force
    Write-Host "Removed Startup shortcut: $shortcutPath" -ForegroundColor Yellow
} else {
    Write-Host "Startup shortcut not found: $shortcutPath" -ForegroundColor Yellow
}
