# Unregister the Yukarinko server Scheduled Task
$ErrorActionPreference = 'SilentlyContinue'
$taskName = 'YukarinkoServer'
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue | Out-Null
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false | Out-Null
    Write-Host "Removed Scheduled Task '$taskName'." -ForegroundColor Yellow
} else {
    Write-Host "Scheduled Task '$taskName' not found." -ForegroundColor Yellow
}
