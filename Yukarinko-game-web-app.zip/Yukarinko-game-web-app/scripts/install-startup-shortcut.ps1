# Create a Startup shortcut to run the keep-alive server script at user logon (no admin required)
$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$keepAlive = Join-Path $scriptDir 'keep-alive.ps1'
if (!(Test-Path $keepAlive)) { throw "Keep-alive script not found: $keepAlive" }

$startup = [Environment]::GetFolderPath('Startup')
$shortcutPath = Join-Path $startup 'YukarinkoServer.lnk'

$ps = (Get-Command powershell).Source
$arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$keepAlive`""

$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut($shortcutPath)
$sc.TargetPath = $ps
$sc.Arguments = $arguments
$sc.WorkingDirectory = (Split-Path -Parent $scriptDir)
$sc.WindowStyle = 7  # Minimized
$sc.Description = 'Yukarinko Node server keep-alive'
$sc.Save()

Write-Host "Created Startup shortcut: $shortcutPath" -ForegroundColor Green
