# Register a Scheduled Task to keep Yukarinko server running 24/7 at user logon
# Requires: Windows, PowerShell 5+, Node installed

$ErrorActionPreference = 'Stop'

$taskName = 'YukarinkoServer'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$keepAlive = Join-Path $scriptDir 'keep-alive.ps1'

if (!(Test-Path $keepAlive)) {
    throw "Keep-alive script not found: $keepAlive"
}

# Build action to run PowerShell hidden with execution policy bypass
$ps = (Get-Command powershell).Source
$arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$keepAlive`""
$action = New-ScheduledTaskAction -Execute $ps -Argument $arguments

# Trigger: at logon of current user
$trigger = New-ScheduledTaskTrigger -AtLogOn

# Settings: start when available, restart on failure, ignore new if already running
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)

# Register the task under current user context
$task = Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Description 'Runs Yukarinko Node server with auto-restart' -Force

Start-ScheduledTask -TaskName $taskName

Write-Host "Installed and started Scheduled Task '$taskName'." -ForegroundColor Green
Write-Host "It will run at every logon and keep the server alive." -ForegroundColor Green
