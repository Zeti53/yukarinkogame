# Keep Yukarinko Node server alive 24/7 (auto-restart on crash)
# Runs node server.js, restarts after exit, logs to logs/server.log

$ErrorActionPreference = 'SilentlyContinue'

# Resolve project root (this script is in scripts/)
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
Set-Location $projectRoot

# Ensure logs directory exists
$logs = Join-Path $projectRoot 'logs'
if (!(Test-Path $logs)) { New-Item -ItemType Directory -Path $logs | Out-Null }
$logFile = Join-Path $logs 'server.log'

function Write-Log($msg){
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    "[$ts] $msg" | Out-File -FilePath $logFile -Append -Encoding utf8
}

function PortBusy(){
    $conns = Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue
    return $null -ne $conns
}

Write-Log 'Keep-alive started.'

while ($true) {
    if (PortBusy) {
        Write-Log 'Port 8080 already in use. Waiting 10s...'
        Start-Sleep -Seconds 10
        continue
    }

    Write-Log 'Starting: node server.js'
    try {
        # Redirect stdout+stderr to log, keep console hidden when launched from Scheduled Task
        & node server.js *>> $logFile
        $code = $LASTEXITCODE
        Write-Log "Process exited with code $code. Restarting in 3s..."
    } catch {
        Write-Log "Server crashed: $($_.Exception.Message). Restarting in 5s..."
        Start-Sleep -Seconds 5
    }

    Start-Sleep -Seconds 3
}
