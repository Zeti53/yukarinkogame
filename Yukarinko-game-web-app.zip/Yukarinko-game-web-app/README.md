# Yukarinko — playable HTML5 runner

This is a small, single-page HTML5 canvas runner game (right-scrolling). The project is static and ready to be hosted anywhere that serves static files (GitHub Pages, Netlify, Surge, S3, etc.).

What this folder contains
- `index.html` — the game page
- `style.css` — page styles and watermark
- `scrypt.js` — game logic and rendering

How to test locally
1. Easiest quick test (requires Python 3 installed):

```powershell
# from the project folder
python -m http.server 8000
# then open http://localhost:8000 in your browser
```

2. Use the included PowerShell helper (Windows):

```powershell
.\serve.ps1
# This will start a local server and open the default browser to the page.
```

Deploying / sharing options

- GitHub Pages (recommended for simple hosting):
  1. Create a new GitHub repository and push this folder (or use an existing one).
  2. In the repo settings, under "Pages", choose the branch (`main` or `master`) and `/ (root)` as the folder.
  3. Save — your site will be available at `https://<your-username>.github.io/<repo-name>/`.

- Netlify / Vercel / Surge:
  - Drag & drop the folder (or the zipped files) into the service dashboard to deploy instantly.

- ZIP and share:
  - Zip the folder and send the archive. The recipient can unzip and serve locally.

Tips for nicer sharing
- Add a real logo image and update `style.css` to use it as a watermark instead of the placeholder text (search for `body::before` in `style.css`).
- If you want a custom domain, configure DNS in your hosting provider and follow GitHub Pages / Netlify docs to add a CNAME.

If you'd like, I can:
- Add a small preview image (`og:image`) and sample social preview graphic.
- Prepare a one-click GitHub repo creation script (requires GitHub CLI) or a ZIP you can download.

Enjoy — tell me which hosting option you prefer and I'll help finalize the steps.
