// Auth helper functions
function checkAuth() {
    const token = localStorage.getItem('token');
    return token !== null;
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.removeItem('userId');
    localStorage.removeItem('highScore');
    localStorage.removeItem('totalScore');
    localStorage.removeItem('gamesPlayed');
    window.location.href = 'login.html';
}

function getUsername() {
    return localStorage.getItem('username') || 'Użytkownik';
}

function getUserId() {
    return localStorage.getItem('userId');
}

function getHighScore() {
    return parseInt(localStorage.getItem('highScore')) || 0;
}

function getTotalScore() {
    return parseInt(localStorage.getItem('totalScore')) || 0;
}

function getGamesPlayed() {
    return parseInt(localStorage.getItem('gamesPlayed')) || 0;
}

function setHighScore(score) {
    localStorage.setItem('highScore', score.toString());
}

function setTotalScore(score) {
    localStorage.setItem('totalScore', score.toString());
}

function setGamesPlayed(count) {
    localStorage.setItem('gamesPlayed', count.toString());
}

// Protect pages that require authentication
function requireAuth() {
    if (!checkAuth()) {
        window.location.href = 'login.html';
    }
}

// Redirect if already logged in (for login/register pages)
function redirectIfAuthenticated() {
    if (checkAuth()) {
        window.location.href = 'index.html';
    }
}

// Save score to server
async function saveScore(score) {
    const userId = getUserId();
    if (!userId) return;
    
    try {
        const response = await fetch('/api/save-score', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId, score })
        });
        
        const data = await response.json();
        if (response.ok) {
            if (data.highScore) setHighScore(data.highScore);
            if (data.totalScore !== undefined) setTotalScore(data.totalScore);
            if (data.gamesPlayed !== undefined) setGamesPlayed(data.gamesPlayed);
        }
    } catch (error) {
        console.error('Error saving score:', error);
    }
}


